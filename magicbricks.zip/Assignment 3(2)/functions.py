from bs4 import BeautifulSoup
from requests import get
import pandas as pd
import re

# price of the property
def price_f(html_soup):
    price=html_soup.find('span',class_="rupee").next_sibling.strip()
    return price

# headline of property
def headline_f(html_soup):
    headline=html_soup.find('div',class_="propBhk").h1.span.text
    return headline

# name of owner or agent 
def owner_agent_f(html_soup):
    try:
        owner_agent=html_soup.find('div',class_="nameValue").text
        return owner_agent
    except:
        owner=html_soup.find('div',class_="CA_name_Detail").div.text
        return owner

# number of bedrooms
def bedroom_f(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")
    for bedroom in prop_info:
        if "Bedrooms" in bedroom.div.text:
            no_bedroom=bedroom.find('div',class_="p_value").div.text
            #no_bedroom=no_bedroom.split('\n')[0]
            return no_bedroom

# number of bathrooms
def bathroom_f(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")
    for bathroom in prop_info:
        if "Bathrooms" in bathroom.div.text:
            no_bathroom=bathroom.find('div',class_="p_value").text
            return no_bathroom

# number of balcony
def balcony_f(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")    
    for balcony in prop_info:
        if "Balcony" in balcony.div.text:
            no_balcony=balcony.find('div',class_="p_value").text
            return no_balcony
# price per squarefeet

def p_p_sqft(html_soup):    
    prop_info=html_soup.find_all('div',class_="p_infoColumn")    
    for p_sqft in prop_info:
        if "Super area" in p_sqft.text:
            price_per_sqft=re.sub('[ ,/sqft]',"",p_sqft.find('div',class_="fo_11px c_dark_gray").text)
            return price_per_sqft

# super area
def super_a(html_soup):    
    prop_info=html_soup.find_all('div',class_="p_infoColumn")    
    for super_a in prop_info:
        if "Super area" in super_a.div.text:
            super_area=super_a.find('div',class_="p_value").span.text
            return super_area

# status of property
def p_status_f(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")
    for status in prop_info:
        if "Status" in status.div.text:
            prop_status=status.find('div',class_="p_value").text
            return prop_status

# transaction type
def trans_f(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")
    for transaction in prop_info:
        if "Transaction type" in transaction.div.text:
            transaction_type=transaction.find('div',class_="p_value").text
            return transaction_type

# number of floors
def n_floor(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")
    for floor in prop_info:
        if "Floor" in floor.div.text:
            no_floor=floor.find('div',class_="p_value").text
            return no_floor

# availability ofcar parking    
def c_parking(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoColumn")
    for parking in prop_info:
        if "Car parking" in parking.div.text:
            car_parking=parking.find('div',class_="p_value").text
            return car_parking

# furnishing    
def furnish_s(html_soup):
    try:    
        prop_info=html_soup.find_all('div',class_="p_infoColumn")
        for furnish in prop_info:
            if "Furnished status" in furnish.div.text:
                furnished_status=furnish.find('div',class_="p_value").text
                return furnished_status
    except:
        prop_disc=html_soup.find_all('div',class_="p_infoRow")
        for furnish in prop_disc:
            if "Furnishing" in furnish.text:
                furnished_status=furnish.find('div',class_="p_value").text
                return furnished_status

# lift           
def lift_f(html_soup):
    try:   
        prop_info=html_soup.find_all('div',class_="p_infoColumn")
        for lift in prop_info:
            if "Lifts" in lift.div.text:
                lifts=lift.find('div',class_="p_value").text
                return lifts
    except:
        prop_disc=html_soup.find_all('div',class_="p_infoRow")
        for lift in prop_disc:
            if "Lift" in lift.text:
                lifts=lift.find('div',class_="p_value").text
                return lifts

# landmarks            
def land_m(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoRow")
    for landmark in prop_info:
            if "Landmarks" in landmark.text:
                landmarks=landmark.find('div',class_="p_value").text
                return landmarks

# age of the construction    
def age_c(html_soup):
    prop_info=html_soup.find_all('div',class_="p_infoRow")
    age_of_construction="not given"
    for age in prop_info:
        if "Age of Construction" in age.text:
            age_of_construction=age.find('div',class_="p_value").text
            return age_of_construction

# detailed description about the property
def desc(html_soup):
    try:
        prop_desc=html_soup.find('div',class_="prop-desc").div.text
        return prop_desc
    except:
        prop_desc=html_soup.find('div',class_="descriptionCont")
        prop_desc=html_soup.find_all('div',class_="p_infoRow")
        prop_desc=prop_desc[0].text
        return prop_desc

# price comparison        
def price_c(html_soup):
    prop_det=html_soup.find_all('div',class_="column")
    for price_c in prop_det:
        if "Price comparison" in price_c.div.text:
            price_comparison=price_c.find('div',class_="pc_value").find('span',class_="semiBold").text
            return price_comparison

# expected rent
def e_rent(html_soup):
    prop_det=html_soup.find_all('div',class_="column")
    expected_rent="not given"
    for e_rent in prop_det:
        if "Expected rent" in e_rent.div.text:
            expected_rent=e_rent.find('div',class_="pc_value").find('span',class_="semiBold").text
            return expected_rent

# monthly emi
def m_emi_f(html_soup):
    prop_det=html_soup.find_all('div',class_="column")
    for m_emi in prop_det:
        if "Monthly EMI" in m_emi.div.text:
            monthly_emi=m_emi.find('div',class_="pc_value").find('span',class_="semiBold").text
            return monthly_emi

# price breakup
def p_breakup(html_soup):
    prop_disc=html_soup.find_all('div',class_="p_infoRow")
    for p_break in prop_disc:
        if "Price Breakup" in p_break.text:
            price_breakup=p_break.find('span',class_="semiBold").text
            return price_breakup

# adrress
def p_addrs(html_soup):
    prop_disc=html_soup.find_all('div',class_="p_infoRow")
    try:    
        for p_address in prop_disc:
            if "Address" in p_address.text:
                address=re.sub("What\'s Nearby","",p_address.find('div',class_="p_value").text)
                return address
    except:
        pass
